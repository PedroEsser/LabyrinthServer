
package labyrinthserver;

import java.awt.Color;
import java.awt.Point;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Server {
  
        private int port = 0;
        private ServerClient[] client = new ServerClient[8];
        private Labyrinth labyrinth;
        private String labyrinthInformation;
        private boolean gameIsRunning = false;
        private boolean serverIsFull = false;
        private int numberOfPlayers;
        private int firstAvailableSlot;

        public Server(){
                Scanner scan = new Scanner(System.in);
                
                System.out.println("Number of Players");
                numberOfPlayers = scan.nextInt();
                if(numberOfPlayers > 8){
                        numberOfPlayers = 8;
                }else if(numberOfPlayers < 1){
                        numberOfPlayers = 1;
                }
                
                System.out.println("Port:");
                port = scan.nextInt();
                
                System.out.println("Width:");
                int width = scan.nextInt();
                
                System.out.println("Height:");
                int height = scan.nextInt();
                
                labyrinth = new Labyrinth(width, height);
                labyrinthInformation = width + ":" + height + labyrinth.getStandingWallsAsString();
                
                start();
        }
        
        public void start() {
                try {
                        ServerSocket server = new ServerSocket(port);
                        System.out.println("Server running on port " + port);
                        while (true) {
                                addPlayer(server.accept());
                        }
                } catch (Exception e) {
                        e.printStackTrace();
                }
        }
        
        private void addPlayer(Socket socket){
                if(!serverIsFull && !gameIsRunning){
                        for(int i = 0 ; i < 8 ; i++){
                                if(client[i] == null){
                                        firstAvailableSlot = i;
                                        break;
                                }
                        }

                        String nextMessage = nextStartMessage();
                        Square nextSquare = getNextStartSquare();
                        int nextColor = getNextColor();
                        String nextColorAsString = getNextColorAsString();
                        client[firstAvailableSlot] = new ServerClient(firstAvailableSlot, this, socket);
                        System.out.println("Player " + (firstAvailableSlot + 1) + " has connected!");
                        client[firstAvailableSlot].setSquare(nextSquare);
                        client[firstAvailableSlot].setcolor(nextColor);
                        client[firstAvailableSlot].setColorAsString(nextColorAsString);
                        client[firstAvailableSlot].send(nextMessage);
                        
                        checkIfCanStart();
                }
        }
        
        public void deleteClient(int i) {
                client[i] = null;
                serverIsFull = false;
        }
        
        private void checkIfCanStart(){
                int help = 0;
                for(int i = 0 ; i < 8 ; i++){
                        if(client[i] != null){
                                help++;
                        }
                }
                if(help == numberOfPlayers){
                        serverIsFull = true;
                        startSequence();
                }
        }
        
        public void broadcast(String buffer) {
                
                if(gameIsRunning){
                        String[] splitBuffer = buffer.split(",");
                        int index = Integer.parseInt(splitBuffer[0]);
                        String direction = splitBuffer[1];

                        if(validDirection(index, direction)){

                                Square lastPosition = client[index].getCurrentSquare();
                                String lastPositionString = lastPosition.getI() + "," + lastPosition.getJ();
                                Point dir;
                                switch(direction){
                                        case "right" : dir = new Point(1,0);
                                        break;
                                        case "left" : dir = new Point(-1,0);
                                        break;
                                        case "up" : dir = new Point(0,-1);
                                        break;
                                        case "down" : dir = new Point(0,1);
                                        break;
                                        default: dir = new Point();
                                        break;
                                }

                                Square newSquare = labyrinth.getSquareAt(lastPosition.getI() + dir.x, lastPosition.getJ() + dir.y);
                                String information;
                                if(labyrinth.checkGoal(newSquare)){
                                        gameIsRunning = false;
                                        information = "w," + client[index].getColorAsString();
                                }else{
                                        client[index].setSquare(newSquare);
                                        String newPosition = newSquare.getI() + "," + newSquare.getJ();
                                        String color = "," + client[index].getColor() + ",";

                                        information = "m," + lastPositionString + color + newPosition;
                                }

                                for (int i = 0; i < 8; i++) {
                                        if (client[i] != null) {
                                                client[i].send(information);
                                        }
                                }

                        }
                }
        }
        
        private boolean validDirection(int i, String direction){
                Square s = client[i].getCurrentSquare();
                switch(direction){
                        case "right" : return s.getRightWall().isBroken();
                        case "left" : return s.getLeftWall().isBroken();
                        case "up" : return s.getUpWall().isBroken();
                        case "down" : return s.getDownWall().isBroken();
                        default : return false;
                }
        }
        
        private void startSequence(){
                
                try {
                        Thread.sleep(2000);
                } catch (InterruptedException ex) {
                }
                
                for (int i = 0; i < 8; i++) {
                        if (client[i] != null) {
                                client[i].send("s");
                        }
                }
                
                for(int i = 0 ; i < 4 ; i++){
                        
                        try {
                                Thread.sleep(1000);
                        } catch (InterruptedException ex) {
                        }
                        
                        for (int j = 0; j < 8; j++) {
                                if (client[j] != null) {
                                        client[j].send("c," + (3-i));
                                }
                        }
                }
                
                for(int i = 0 ; i < 8 ; i++){
                        if(client[i] != null){
                                for(int j = 0 ; j < 8 ; j++){
                                        if(client[j] != null){
                                                int x = client[j].getCurrentSquare().getI();
                                                int y = client[j].getCurrentSquare().getJ();
                                                String information = "m," + x + "," + y + "," + client[j].getColor() + "," + x + "," + y;
                                                client[i].send(information);
                                        }
                                }
                        }
                }
                gameIsRunning = true;
        }
        
        private String nextStartMessage(){
                
                String startMessage = "l:";
                
                startMessage += getNextColorAsString() + ":";
                startMessage += getNextColor() + ":";
                startMessage += getNextStartSquare().getI() + ":";
                startMessage += getNextStartSquare().getJ() + ":";
                
                startMessage += labyrinthInformation;
                
                return startMessage;
        }
        
        private Square getNextStartSquare(){
                
                if(numberOfPlayers <= 4){
                        
                        switch (firstAvailableSlot) {
                        case 0: return labyrinth.getSquareAt(0,0);
                        case 1: return labyrinth.getSquareAt(labyrinth.getWidth() - 1, 0);
                        case 2: return labyrinth.getSquareAt(0,labyrinth.getHeight() - 1);
                        case 3: return labyrinth.getSquareAt(labyrinth.getWidth() - 1, labyrinth.getHeight() - 1);
                        default: return null; 
                        }
                }else{
                        switch (firstAvailableSlot) {
                        case 0: return labyrinth.getSquareAt(labyrinth.getWidth()/4 - 1,0);
                        case 1: return labyrinth.getSquareAt(labyrinth.getWidth()*3/4 - 1, 0);
                        case 2: return labyrinth.getSquareAt(labyrinth.getWidth() - 1, labyrinth.getHeight()/4 - 1);
                        case 3: return labyrinth.getSquareAt(labyrinth.getWidth() - 1, labyrinth.getHeight()*3/4 - 1);
                        case 4: return labyrinth.getSquareAt(labyrinth.getWidth()*3/4, labyrinth.getHeight() - 1);
                        case 5: return labyrinth.getSquareAt(labyrinth.getWidth()/4 - 1, labyrinth.getHeight() - 1);
                        case 6: return labyrinth.getSquareAt(0, labyrinth.getHeight()*3/4 - 1);
                        case 7: return labyrinth.getSquareAt(0, labyrinth.getHeight()/4 - 1);
                        default: return null; 
                        }
                }
                 
        }
        
        private int getNextColor(){
                
                switch (firstAvailableSlot){
                        case 0: return Color.RED.getRGB();
                        case 1: return new Color(64,64,255).getRGB();
                        case 2: return Color.YELLOW.getRGB();
                        case 3: return Color.MAGENTA.getRGB();
                        case 4: return Color.CYAN.getRGB();
                        case 5: return new Color(255,100,0).getRGB();
                        case 6: return new Color(0,0,100).getRGB();
                        case 7: return new Color(128,0,128).getRGB();
                        default: return 0;
                }
        }
        
        private String getNextColorAsString(){
                
                switch (firstAvailableSlot){
                        case 0: return "Rot";
                        case 1: return "Blau";
                        case 2: return "Gelb";
                        case 3: return "Magenta";
                        case 4: return "Cyan";
                        case 5: return "Orange";
                        case 6: return "DunkelBlau";
                        case 7: return "Lila";
                        default: return null;
                }
        }

        public static void main(String[] args) {
                new Server();
        }
}