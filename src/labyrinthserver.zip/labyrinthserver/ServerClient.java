
package labyrinthserver;

import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ServerClient{
  
        private int index = 0;
        private Server server = null;
        private BufferedReader read = null;
        private PrintWriter write = null;
        private Square currentSquare;
        private int color;
        private String colorAsString;

        public ServerClient(int index, Server server, Socket socket) {
                try {
                        this.index = index;
                        this.server = server;
                        read = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        write = new PrintWriter(socket.getOutputStream());
                        listen();
                } catch (Exception e) {
                        e.printStackTrace();
                }
        }

        public void send(String buffer) {
                try {
                        write.write(buffer + "\n");
                        write.flush();
                } catch (Exception e) {
                        e.printStackTrace();
                }
        }

        private void listen() {
                new Thread(() ->{
                        try {
                                while (true) {
                                        String info = read.readLine();
                                        switch(info.charAt(0)){
                                                case 'x':server.deleteClient(index);
                                                send("");
                                                System.out.println("Player " + (index + 1) + " has disconnected!");
                                                break;
                                                default:server.broadcast(index + "," + info);
                                                break;
                                        }
                                }
                        } catch (Exception e) {
                                server.deleteClient(index);
                                System.out.println("Player " + (index + 1) + " has disconnected!");
                        }
                }).start();
                
        }
        
        public Square getCurrentSquare(){
                return currentSquare;
        }
        
        public void setSquare(Square s){
                this.currentSquare = s;
        }
        
        public void setcolor(int c){
                this.color = c;
        }
        
        public int getColor(){
                return color;
        }
        
        public void setColorAsString(String color){
                this.colorAsString = color;
        }
        
        public String getColorAsString(){
                return colorAsString;
        }
}